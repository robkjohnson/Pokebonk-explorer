# Re-extracting after a game update
1. Save the new build's files into `raw/<version>/` (all pokebonk.com scripts + data/*.json + data/i18n/en.json + version.json).
2. From this folder: `node extract.mjs ../raw/<version> ../extracted`
3. `python3 make_csv.py ../extracted/<version>` for the CSV copies
4. Check `extracted/<version>/meta.json` → `warnings` (empty = every table found).
Needs Node.js 18+. acorn/acorn-walk are bundled in node_modules.
